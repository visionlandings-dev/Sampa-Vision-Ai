'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowRight, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Textarea } from '@/components/ui/Textarea'
import { Progress } from '@/components/ui/Progress'
import { BRIEFING_QUESTIONS } from '@/config/content'
import type { BriefingAnswers } from '@/types'

const EMPTY_ANSWERS: BriefingAnswers = {
  produto: '', publico: '', dor: '', diferencial: '', beneficios: '', oferta: '', cta: '',
}

export function BriefingWizard() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<BriefingAnswers>(EMPTY_ANSWERS)
  const [touched, setTouched] = useState(false)

  const total = BRIEFING_QUESTIONS.length
  const question = BRIEFING_QUESTIONS[step]
  const value = answers[question.field]
  const isValid = value.trim().length >= question.minLength
  const progress = ((step + 1) / total) * 100
  const isLast = step === total - 1

  const updateAnswer = useCallback(
    (text: string) => {
      setAnswers((prev) => ({ ...prev, [question.field]: text }))
    },
    [question.field]
  )

  const goNext = useCallback(() => {
    if (!isValid) {
      setTouched(true)
      return
    }
    setTouched(false)

    if (isLast) {
      // Persiste no sessionStorage e navega para a tela de geração.
      // (sessionStorage evita perder o briefing em um refresh acidental
      // sem precisar de backend antes da geração de fato acontecer)
      sessionStorage.setItem('sv_briefing', JSON.stringify(answers))
      router.push('/briefing/gerando')
      return
    }

    setStep((s) => s + 1)
  }, [isValid, isLast, answers, router])

  const goBack = useCallback(() => {
    setTouched(false)
    setStep((s) => Math.max(0, s - 1))
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Enter sem shift avança — comportamento esperado em wizards de texto curto
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      goNext()
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* ── PROGRESSO ── */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-mono-sm text-ash uppercase tracking-[0.14em]">
            Pergunta {step + 1} de {total}
          </span>
          <span className="font-mono text-mono-sm text-electric uppercase tracking-[0.14em]">
            ~{Math.max(1, Math.ceil((total - step) * 0.3))} min restantes
          </span>
        </div>
        <Progress value={progress} />
      </div>

      {/* ── PERGUNTA ── */}
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -16 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="font-mono text-mono-xs uppercase tracking-[0.22em] text-electric block mb-3">
            {String(question.number).padStart(2, '0')} / {String(total).padStart(2, '0')}
          </span>

          <h2 className="font-display font-bold text-display-sm text-bone mb-2">
            {question.question}
          </h2>
          <p className="font-body text-body-sm text-ash mb-6">{question.helper}</p>

          <Textarea
            value={value}
            onChange={(e) => updateAnswer(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={question.placeholder}
            error={touched && !isValid}
            autoFocus
            aria-label={question.question}
            aria-invalid={touched && !isValid}
            aria-describedby={touched && !isValid ? 'briefing-error' : undefined}
          />

          {touched && !isValid && (
            <p id="briefing-error" className="font-mono text-mono-sm text-error mt-2">
              Conte um pouco mais — pelo menos {question.minLength} caracteres.
            </p>
          )}
        </motion.div>
      </AnimatePresence>

      {/* ── NAVEGAÇÃO ── */}
      <div className="flex items-center justify-between mt-8">
        <Button
          variant="ghost"
          onClick={goBack}
          disabled={step === 0}
          className="invisible:opacity-0"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          Voltar
        </Button>

        <Button onClick={goNext}>
          {isLast ? 'Gerar minha página' : 'Próxima'}
          <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
        </Button>
      </div>
    </div>
  )
}
